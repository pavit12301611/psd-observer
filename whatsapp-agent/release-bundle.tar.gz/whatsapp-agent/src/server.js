// server.js — the local HTTP bridge + installable phone app (PWA).
//
// This is what the Observer app talks to instead of https://api.observer-ai.com:
//   POST /tools/send-whatsapp   Observer agents' sendWhatsapp(), free + unlimited
//   GET  /remote/listen         long-poll mailbox (patched app/src/mcp/remote.ts)
//   POST /remote/reply          MCP answers coming back to WhatsApp
//   GET  /remote/status         "is the phone linked?"
//
// And it is a complete control panel of its own — no Observer needed:
//   GET  /                      installable phone app (chat + controls + files)
//   POST /api/login             dashboard PIN → token
//   POST /api/chat              talk to the agent from the app
//   GET  /api/status            live status for the app
//   GET  /api/brains            which free model serves what (workload routing)
//   GET  /api/files             received + shared files
//   POST /api/action            run a single action directly
//   POST /api/send              send a message to the owner on WhatsApp
//
// Security: binds 0.0.0.0 so your phone on the same Wi-Fi can use it, but
// every data route needs the bridge token (or the PIN to get one). Login is
// rate-limited. Sending to any number other than the owner is refused.

import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { maskNumber, normalizeNumber } from './allowlist.js';
import { ROOT } from './config.js';
import { cachedIcon } from './webapp.js';
import * as apps from './apps.js';
import * as files from './files.js';
import * as pc from './pccontrol.js';
import * as hands from './hands.js';
import { pngSize } from './elementfinder.js';
import { routerFor } from './router.js';
import * as solver from './solver.js';
import * as tts from './tts.js';
import { transcribeAudio, transcriptionAvailable } from './transcribe.js';

const MAX_BODY = 30 * 1024 * 1024;
const VERSION = '3.1.7';
const WEB_DIR = path.join(ROOT, 'webapp');

const STATIC = {
  '/': ['index.html', 'text/html; charset=utf-8'],
  '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/styles.css': ['styles.css', 'text/css; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'],
  '/sw.js': ['sw.js', 'text/javascript; charset=utf-8'],
  '/manifest.webmanifest': ['manifest.webmanifest', 'application/manifest+json'],
};

function readJsonBody(req) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > MAX_BODY) { reject(Object.assign(new Error('Request body too large (30 MB max)'), { status: 413 })); req.destroy(); return; }
      chunks.push(chunk);
    });
    req.on('end', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      if (!raw) return resolve({});
      try { resolve(JSON.parse(raw)); } catch { reject(Object.assign(new Error('Invalid JSON body'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

const stripDataPrefix = (b64) => (typeof b64 === 'string' && b64.includes(',') && b64.startsWith('data:') ? b64.slice(b64.indexOf(',') + 1) : b64);
const dataUrl = (buffer, mime = 'image/png') => `data:${mime};base64,${Buffer.from(buffer).toString('base64')}`;

/** Shape an agent reply for the phone app. */
export function replyForApp(reply) {
  if (reply == null) return { ok: true, text: '' };
  if (typeof reply === 'string') return { ok: true, text: reply };
  const out = { ok: true, text: reply.text ?? '' };
  const images = [];
  if (reply.image) images.push(dataUrl(reply.image));
  for (const extra of reply.extraImages ?? []) images.push(dataUrl(extra));
  if (images.length) out.images = images;
  if (reply.document) {
    out.documentName = reply.document.fileName;
    if (reply.document.path) out.documentPath = reply.document.path;
  }
  if (reply.video) out.videoName = 'screen-recording.mp4';
  if (reply.audio) {
    out.audio = dataUrl(reply.audio, reply.mimetype ?? 'audio/ogg');
    out.audioMimetype = reply.mimetype;
  }
  if (reply.poll) out.text = `📊 ${reply.poll.name}\n${reply.poll.values.map((v) => `• ${v}`).join('\n')}`;
  return out;
}

/** Strong ETag for one frame, so an unchanged screen costs no bandwidth. */
export function screenTag(buffer) {
  return `"${crypto.createHash('sha1').update(buffer).digest('hex').slice(0, 20)}"`;
}

function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a ?? '')).digest();
  const hb = crypto.createHash('sha256').update(String(b ?? '')).digest();
  return crypto.timingSafeEqual(ha, hb);
}

export function createBridgeServer({
  config, store, whatsapp, mailbox, actions, harness = null, voice = null, wavoip = null, runOwner, log = console,
  // Injectable so tests never touch a real desktop, and so the number of
  // screenshots per request is explicit and measurable.
  screen = null,
}) {
  const scr = screen ?? {
    capture: (opts) => pc.captureScreenshot(opts),
    click: (x, y) => pc.click(x, y),
    key: (combo) => pc.keyCombo(combo),
    type: (text) => pc.typeText(text),
  };
  // Size of the last frame the phone asked for. A tap then needs ZERO extra
  // screenshots — important on Wayland, where every capture can pop the
  // portal's "share your screen" prompt.
  let lastFrameSize = null;
  const authed = (req, url) => {
    const bearer = (req.headers.authorization ?? '').replace(/^Bearer\s+/i, '');
    // Constant-time: a plain === leaks the token a byte at a time to anything
    // that can time requests on the LAN.
    return [req.headers['x-bridge-token'], bearer, url.searchParams.get('t')]
      .some((candidate) => candidate != null && safeEqual(candidate, config.bridgeToken));
  };

  const loginAttempts = new Map(); // ip → {count, resetAt}
  function loginAllowed(ip) {
    const now = Date.now();
    const entry = loginAttempts.get(ip);
    if (!entry || entry.resetAt < now) {
      loginAttempts.set(ip, { count: 0, resetAt: now + 5 * 60_000 });
      return true;
    }
    return entry.count < 12;
  }
  function recordLogin(ip) {
    const entry = loginAttempts.get(ip) ?? { count: 0, resetAt: Date.now() + 5 * 60_000 };
    entry.count += 1;
    loginAttempts.set(ip, entry);
  }

  function json(res, status, body) {
    const payload = JSON.stringify(body);
    res.writeHead(status, { 'content-type': 'application/json', 'content-length': Buffer.byteLength(payload), 'cache-control': 'no-store' });
    res.end(payload);
  }

  async function sendPayload({ message, text, images, videos, mediaUrls, media_urls }) {
    const body = String(message ?? text ?? '');
    const imgs = (images ?? []).slice(0, 5).map((b64) => Buffer.from(stripDataPrefix(b64), 'base64'));
    const vids = (videos ?? []).slice(0, 2).map((b64) => Buffer.from(stripDataPrefix(b64), 'base64'));
    const hosted = (mediaUrls ?? media_urls ?? []).filter((u) => typeof u === 'string' && /^https?:\/\//.test(u)).slice(0, 5);
    if (!imgs.length && !vids.length && hosted.length) {
      await whatsapp.sendToOwner({ imageUrls: hosted, text: body || 'Media from Observer AI' });
      return;
    }
    if (imgs.length) {
      await whatsapp.sendToOwner({ image: imgs[0], extraImages: imgs.slice(1), text: body || 'Media from Observer AI' });
    } else if (vids.length) {
      await whatsapp.sendToOwner({ video: vids[0], text: body || 'Video from Observer AI' });
    } else {
      await whatsapp.sendToOwner(body || 'Alert from Observer AI');
    }
  }

  function listShared() {
    try {
      return fs.readdirSync(config.sharedDir)
        .map((name) => {
          const full = path.join(config.sharedDir, name);
          const stat = fs.statSync(full);
          return stat.isFile() ? { name, path: full, size: stat.size } : null;
        })
        .filter(Boolean)
        .slice(0, 100);
    } catch {
      return [];
    }
  }

  function listDownloads() {
    return (store.data.downloads ?? []).slice(0, 60).map((d) => ({
      name: d.file,
      file: d.file,
      kind: d.kind,
      ts: d.ts,
      path: path.join(config.downloadsDir, d.file),
    }));
  }

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);
    const route = `${req.method} ${url.pathname}`;
    res.setHeader('access-control-allow-origin', '*');
    res.setHeader('access-control-allow-headers', 'content-type, authorization, x-bridge-token');
    res.setHeader('access-control-allow-methods', 'GET, POST, OPTIONS');
    if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

    try {
      // ── public: health, app shell, icons ─────────────────────────────────
      if (route === 'GET /health') {
        return json(res, 200, {
          ok: true,
          service: 'observer-whatsapp-agent',
          version: VERSION,
          whatsapp: whatsapp.status(),
          owner: maskNumber(config.ownerNumber),
          agent: maskNumber(config.agentNumber),
          observerTabConnected: mailbox.observerOnline(),
        });
      }

      if (req.method === 'GET' && url.pathname === '/dashboard') {
        res.writeHead(302, { location: `/${url.search}` });
        return res.end();
      }

      if (req.method === 'GET' && STATIC[url.pathname]) {
        const [file, type] = STATIC[url.pathname];
        try {
          const body = fs.readFileSync(path.join(WEB_DIR, file));
          res.writeHead(200, {
            'content-type': type,
            'content-length': body.length,
            'cache-control': file === 'sw.js' ? 'no-cache' : 'public, max-age=300',
          });
          return res.end(body);
        } catch {
          return json(res, 404, { detail: 'App shell missing on disk (webapp/ folder).' });
        }
      }

      if (req.method === 'GET' && (url.pathname === '/icon-192.png' || url.pathname === '/icon-512.png' || url.pathname === '/apple-touch-icon.png')) {
        const size = url.pathname.includes('512') ? 512 : 192;
        const png = cachedIcon(size);
        res.writeHead(200, { 'content-type': 'image/png', 'content-length': png.length, 'cache-control': 'public, max-age=86400' });
        return res.end(png);
      }

      if (route === 'POST /api/login') {
        const ip = req.socket.remoteAddress ?? 'unknown';
        if (!loginAllowed(ip)) return json(res, 429, { detail: 'Too many attempts. Wait 5 minutes.' });
        const body = await readJsonBody(req);
        const pin = String(body.pin ?? '');
        const ok = pin && (safeEqual(pin, config.dashboardPin) || safeEqual(pin, config.bridgeToken));
        if (!ok) {
          recordLogin(ip);
          return json(res, 401, { detail: 'Wrong PIN. It is printed in the agent console at startup.' });
        }
        loginAttempts.delete(ip);
        return json(res, 200, { ok: true, token: config.bridgeToken });
      }

      if (route === 'GET /qr.png') {
        if (!authed(req, url)) return json(res, 401, { detail: 'Bridge token required (add ?t=<token> — printed in the agent console).' });
        try {
          const png = fs.readFileSync(config.qrPngFile);
          res.writeHead(200, { 'content-type': 'image/png', 'cache-control': 'no-store' });
          return res.end(png);
        } catch { return json(res, 404, { detail: 'No QR right now — either already linked, or WhatsApp is still connecting.' }); }
      }

      if (!authed(req, url)) {
        return json(res, 401, { detail: 'Bridge token required (x-bridge-token header, Bearer, or the dashboard PIN via /api/login). It is printed when the agent starts.' });
      }

      switch (route) {
        case 'GET /api/brains': {
          const router = routerFor(config, console);
          return json(res, 200, {
            ...router.snapshot(),
            tierBudgets: { tiny: 2, light: 3, standard: 5, heavy: 8 },
            model: config.ollamaModel,
          });
        }

        case 'GET /api/status':
          return json(res, 200, {
            version: VERSION,
            whatsapp: whatsapp.status(),
            owner: config.ownerNumber,
            agent: config.agentNumber,
            pairingCode: whatsapp.state.pairingCode,
            hasQr: Boolean(whatsapp.state.lastQr),
            observerTabConnected: mailbox.observerOnline(),
            forwardToObserver: config.forwardToObserver,
            allowSimulate: config.allowSimulate,
            access: actions?.accessReport?.() ?? { level: config.accessLevel },
            agentTools: Boolean(config.agentTools),
            model: config.ollamaModel,
            brains: routerFor(config, console).catalog.map((m) => ({
              id: m.id, label: m.label, local: m.local, vision: m.vision,
              tiers: [m.minTier, m.maxTier], quality: m.quality,
            })),
            harness: harness ? harness.status() : null,
            stats: store.data.stats,
            reminders: store.data.reminders.length,
            cronJobs: (store.data.cronJobs ?? []).length,
            openTodos: store.data.todos.filter((t) => !t.done).length,
            notes: store.data.notes.length,
            pending: store.data.pending ? { text: store.data.pending.text, ts: store.data.pending.ts } : null,
          });

        case 'POST /api/chat': {
          const body = await readJsonBody(req);
          const text = String(body.text ?? '').slice(0, 4000);
          if (!text.trim()) return json(res, 400, { detail: 'text is required' });
          if (body.from && normalizeNumber(body.from) !== config.ownerNumber) {
            return json(res, 403, { detail: 'This agent only listens to the owner.' });
          }
          if (!runOwner) return json(res, 503, { detail: 'Agent is still starting up.' });
          const reply = await runOwner(text);
          return json(res, 200, replyForApp(reply));
        }

        // ── JARVIS voice call (phone app 📞 Call tab) ──────────────────────
        // Browser mic → text (SpeechRecognition, or /api/call/transcribe for
        // browsers without it) → the shared voice brain (intents → API-model
        // tool loop → execute) → JARVIS audio back. One round-trip per turn;
        // /api/call/events mirrors live state while long commands run.
        case 'GET /api/voice': {
          const engines = tts.listTTSEngines(config);
          return json(res, 200, {
            ok: true,
            engines: engines.map((e) => ({ name: e.name, label: e.label })),
            best: engines[0]?.label ?? null,
            statusText: tts.ttsStatus(config),
            transcription: transcriptionAvailable(config),
            voiceCall: config.voiceCall !== false,
            callMode: Boolean(store.data.voiceCallMode || config.whatsappVoiceReplies),
            wavoip: wavoip ? wavoip.status() : null,
          });
        }

        case 'POST /api/voice/test': {
          const body = await readJsonBody(req);
          const sample = String(body.text ?? `Good evening, ${config.jarvisAddress || 'Sir'}. This is JARVIS at your service.`).slice(0, 300);
          try {
            const result = await tts.synthesize(sample, config, log);
            return json(res, 200, { ok: true, audio: dataUrl(result.buffer, (result.mimetype || 'audio/ogg').split(';')[0]), mimetype: result.mimetype, engine: result.engine, text: sample });
          } catch (err) {
            return json(res, 503, { ok: false, detail: err.message, speakInBrowser: sample });
          }
        }

        case 'POST /api/call/start': {
          if (!voice) return json(res, 503, { detail: 'Voice engine is not wired in this build.' });
          if (config.voiceCall === false) return json(res, 403, { detail: 'Voice calls are off (VOICE_CALL=false).' });
          const body = await readJsonBody(req);
          const started = await voice.start('app', body.sessionId ? String(body.sessionId) : null);
          return json(res, 200, {
            ok: true,
            sessionId: started.sessionId,
            greeting: started.greeting,
            spoken: started.spoken,
            state: started.state,
            audio: started.audio ? dataUrl(started.audio.buffer, (started.audio.mimetype || 'audio/ogg').split(';')[0]) : null,
            audioMimetype: started.audio?.mimetype ?? null,
          });
        }

        case 'POST /api/call/say': {
          if (!voice) return json(res, 503, { detail: 'Voice engine is not wired in this build.' });
          if (config.voiceCall === false) return json(res, 403, { detail: 'Voice calls are off (VOICE_CALL=false).' });
          const body = await readJsonBody(req);
          const text = String(body.text ?? '').slice(0, 4000);
          if (!text.trim()) return json(res, 400, { detail: 'text is required' });
          if (body.from && normalizeNumber(body.from) !== config.ownerNumber) {
            return json(res, 403, { detail: 'This agent only listens to the owner.' });
          }
          const result = await voice.say(body.sessionId ? String(body.sessionId) : null, text, { source: 'app' });
          return json(res, 200, {
            ok: true,
            sessionId: result.sessionId,
            heard: result.heard,
            text: result.text ?? '',
            spoken: result.spoken ?? '',
            state: result.state,
            ended: Boolean(result.ended),
            awaitingConfirm: Boolean(result.awaitingConfirm),
            images: (result.images ?? []).map((img) => dataUrl(img)),
            documentName: result.document?.fileName ?? '',
            audio: result.audio ? dataUrl(result.audio.buffer, (result.audio.mimetype || 'audio/ogg').split(';')[0]) : null,
            audioMimetype: result.audio?.mimetype ?? null,
          });
        }

        case 'POST /api/call/transcribe': {
          const body = await readJsonBody(req);
          if (!body.audioBase64) return json(res, 400, { detail: 'audioBase64 is required' });
          const buffer = Buffer.from(stripDataPrefix(body.audioBase64), 'base64');
          if (!buffer.length) return json(res, 400, { detail: 'empty audio' });
          if (buffer.length > 12 * 1024 * 1024) return json(res, 413, { detail: 'audio clip too large (12 MB max)' });
          try {
            const out = await transcribeAudio(config, buffer, String(body.mimeType || 'audio/webm'), log);
            return json(res, 200, { ok: true, text: out.text, provider: out.provider });
          } catch (err) {
            return json(res, 503, { ok: false, detail: err.message });
          }
        }

        case 'POST /api/call/interrupt': {
          if (!voice) return json(res, 503, { detail: 'Voice engine is not wired in this build.' });
          const body = await readJsonBody(req);
          return json(res, 200, { ok: voice.interrupt(String(body.sessionId ?? '')) });
        }

        case 'POST /api/call/stop': {
          if (!voice) return json(res, 503, { detail: 'Voice engine is not wired in this build.' });
          const body = await readJsonBody(req);
          return json(res, 200, { ok: voice.end(String(body.sessionId ?? '')) });
        }

        case 'GET /api/call/events': {
          if (!voice) return json(res, 503, { detail: 'Voice engine is not wired in this build.' });
          const sessionId = url.searchParams.get('session') || '';
          res.writeHead(200, {
            'content-type': 'text/event-stream',
            'cache-control': 'no-store',
            connection: 'keep-alive',
          });
          res.write(`event: ready\ndata: ${JSON.stringify({ sessionId })}\n\n`);
          const unsubscribe = voice.on(sessionId, (event) => {
            try { res.write(`event: ${event.type}\ndata: ${JSON.stringify(event)}\n\n`); } catch { /* client gone */ }
          });
          const heartbeat = setInterval(() => { try { res.write(': heartbeat\n\n'); } catch { /* gone */ } }, 25_000);
          req.on('close', () => { clearInterval(heartbeat); unsubscribe(); });
          return; // socket stays open — this *is* the response
        }

        case 'POST /api/action': {
          if (!actions) return json(res, 503, { detail: 'Actions are not ready yet.' });
          const body = await readJsonBody(req);
          const result = await actions.execute(String(body.name ?? ''), body.args ?? {}, { source: 'app' });
          return json(res, 200, replyForApp(result));
        }

        case 'GET /api/download': {
          // Authenticated file download for the phone app ("Send" in chat).
          const wanted = url.searchParams.get('path') ?? '';
          const resolved = files.resolvePath(wanted, { extraRoots: config.filesExtraRoots ?? [], mustExist: true });
          if (!resolved.ok) return json(res, 400, { detail: resolved.reason });
          const stat = fs.statSync(resolved.path);
          if (stat.isDirectory()) return json(res, 400, { detail: 'That path is a folder, not a file.' });
          res.writeHead(200, {
            'content-type': files.mimeFor(resolved.path),
            'content-length': stat.size,
            'content-disposition': `attachment; filename="${encodeURIComponent(path.basename(resolved.path))}"`,
            'cache-control': 'no-store',
          });
          const stream = fs.createReadStream(resolved.path);
          stream.on('error', (err) => {
            log.error?.(`[bridge] download failed: ${err.message}`);
            if (!res.headersSent) json(res, 500, { detail: err.message });
            else res.destroy(err);
          });
          return stream.pipe(res);
        }

        case 'GET /api/files':
          return json(res, 200, { downloads: listDownloads(), shared: listShared() });

        // ── remote control (phone app / from anywhere over Tailscale) ──────
        // Live screen + tap-to-click. Same PC, same controls as WhatsApp —
        // the phone is just another client of the same agent.
        case 'GET /api/screen': {
          if (!config.allowPcControl) return json(res, 403, { detail: 'PC control is off (ALLOW_PC_CONTROL=false).' });
          const shot = await scr.capture({ portalTimeoutMs: Math.min(Number(config.portalTimeoutMs) || 30_000, 20_000) });
          const size = pngSize(shot) ?? { width: 0, height: 0 };
          if (size.width && size.height) lastFrameSize = size;
          const tag = screenTag(shot);
          // Unchanged screen → 304, no capture wasted on the phone's side and
          // no image re-sent. The phone asks again only when it wants to.
          if (req.headers['if-none-match'] === tag) {
            res.writeHead(304, { etag: tag, 'cache-control': 'no-store', 'x-screen-width': size.width, 'x-screen-height': size.height });
            return res.end();
          }
          const wanted = Math.max(480, Math.min(1920, Number(url.searchParams.get('w')) || 1280));
          const { image, mime } = await hands.shrinkForModel(shot, wanted, 70);
          res.writeHead(200, {
            'content-type': mime,
            'content-length': image.length,
            'cache-control': 'no-store',
            etag: tag,
            'x-screen-width': size.width,
            'x-screen-height': size.height,
          });
          return res.end(image);
        }

        case 'POST /api/tap': {
          if (!config.allowPcControl) return json(res, 403, { detail: 'PC control is off (ALLOW_PC_CONTROL=false).' });
          const body = await readJsonBody(req);
          const rx = Number(body.x);
          const ry = Number(body.y);
          if (!Number.isFinite(rx) || !Number.isFinite(ry)) return json(res, 400, { detail: 'x and y are required (0-1000 relative, or pixels with relative:false)' });
          // Prefer the size of the frame the phone is actually looking at: one
          // screenshot per tap is exactly the "screenshot har second" cost the
          // owner asked to avoid.
          let size = lastFrameSize;
          if (!size) {
            const shot = await scr.capture({ portalTimeoutMs: Math.min(Number(config.portalTimeoutMs) || 30_000, 20_000) });
            size = pngSize(shot) ?? { width: 0, height: 0 };
            if (size.width && size.height) lastFrameSize = size;
          }
          // `relative:true` (the app sends this) means 0-1000 like the hands
          // loop; raw pixels are accepted too.
          const x = body.relative === false
            ? Math.round(rx)
            : Math.round((Math.min(1000, Math.max(0, rx)) / 1000) * (size.width || 1));
          const y = body.relative === false
            ? Math.round(ry)
            : Math.round((Math.min(1000, Math.max(0, ry)) / 1000) * (size.height || 1));
          if (!size.width || x < 0 || y < 0 || x >= size.width || y >= size.height) {
            return json(res, 400, { detail: `Tap outside the screen (${size.width}×${size.height})` });
          }
          await scr.click(x, y);
          log.info?.(`[bridge] tap ${x},${y} from the phone app`);
          return json(res, 200, { ok: true, x, y, width: size.width, height: size.height });
        }

        case 'POST /api/key': {
          if (!config.allowPcControl) return json(res, 403, { detail: 'PC control is off (ALLOW_PC_CONTROL=false).' });
          const body = await readJsonBody(req);
          const key = String(body.key ?? '').trim();
          if (!key) return json(res, 400, { detail: 'key is required (e.g. "ctrl+l", "Return")' });
          await scr.key(key);
          return json(res, 200, { ok: true, key });
        }

        case 'POST /api/type': {
          if (!config.allowPcControl) return json(res, 403, { detail: 'PC control is off (ALLOW_PC_CONTROL=false).' });
          const body = await readJsonBody(req);
          const text = String(body.text ?? '');
          if (!text) return json(res, 400, { detail: 'text is required' });
          await scr.type(text.slice(0, 4000));
          return json(res, 200, { ok: true, chars: Math.min(text.length, 4000) });
        }

        case 'GET /api/apps':
          try {
            return json(res, 200, { apps: apps.appList(apps.discoverApps(), 200).map((a) => ({ id: a.id, name: a.name })) });
          } catch (err) {
            return json(res, 200, { apps: [], detail: err.message });
          }

        case 'POST /api/send': {
          await sendPayload(await readJsonBody(req));
          return json(res, 200, { success: true });
        }

        case 'POST /tools/send-whatsapp': {
          const body = await readJsonBody(req);
          // Owner-only also on the way out: a phone-number `to_number` must be
          // the owner's. Observer-code strings (anchor-apple-…) are accepted
          // and, like the cloud, resolve to the owner's phone — which here is
          // simply the one configured owner.
          const asNumber = normalizeNumber(body.to_number ?? '');
          if (/^\+?\d[\d\s-]{8,}$/.test(String(body.to_number ?? '')) && asNumber !== config.ownerNumber) {
            return json(res, 403, { detail: 'Native WhatsApp bridge is owner-only: it sends solely to the configured OWNER_NUMBER.' });
          }
          await sendPayload(body);
          return json(res, 200, { success: true, message_sid: 'native-whatsapp' });
        }

        case 'POST /tools/is-whitelisted':
          return json(res, 200, { success: true, whitelisted: true, is_whitelisted: true, linked: true, channel: 'whatsapp' });

        case 'GET /remote/listen':
        case 'GET /remote/inbox':
          return json(res, 200, { messages: await mailbox.listen(25_000) });

        case 'GET /remote/status':
          return json(res, 200, {
            linked: whatsapp.status().startsWith('connected') || config.dryRun,
            name: `Native WhatsApp (+${maskNumber(config.agentNumber)})`,
            revoked: false,
          });

        case 'POST /remote/reply': {
          const body = await readJsonBody(req);
          const text = String(body.text ?? '').slice(0, 4000);
          if (!text && !(body.images?.length)) return json(res, 400, { detail: 'text is required' });
          const images = (body.images ?? []).slice(0, 3).map(stripDataPrefix);
          const how = mailbox.deliverReply({ text, images });
          if (how === 'direct') await sendPayload({ message: text, images });
          return json(res, 200, { success: true, deliveredVia: how });
        }

        case 'POST /api/simulate': {
          if (!config.allowSimulate) return json(res, 403, { detail: 'Simulate is off. Set ALLOW_SIMULATE=true (or use --dry-run) to enable it.' });
          const body = await readJsonBody(req);
          const result = await whatsapp.simulate(String(body.text ?? ''), body.from ? normalizeNumber(body.from) : config.ownerNumber);
          return json(res, 200, result);
        }

        // ── DeepSeek Harness IPC + Phone/Desktop Control Routes ──────────
        case 'POST /api/whatsapp/send': {
          const body = await readJsonBody(req);
          const kind = String(body.kind || 'text');
          if (kind === 'screenshot') {
            const shot = await pc.captureScreenshot({ portalTimeoutMs: Math.min(Number(config.portalTimeoutMs) || 30_000, 25_000) });
            await whatsapp.sendToOwner({ image: shot, text: String(body.caption || '📸 Fedora Desktop') });
            return json(res, 200, { ok: true, via: whatsapp.status() });
          }
          if (kind === 'file') {
            const target = path.resolve(String(body.filePath || ''));
            if (!fs.existsSync(target) || fs.statSync(target).isDirectory()) {
              return json(res, 400, { ok: false, detail: `File not found: ${target}` });
            }
            const buf = fs.readFileSync(target);
            const ext = path.extname(target).toLowerCase();
            const isImg = Boolean(body.asImage) || ['.png', '.jpg', '.jpeg', '.webp'].includes(ext);
            if (isImg) {
              await whatsapp.sendToOwner({ image: buf, text: String(body.caption || path.basename(target)) });
            } else {
              await whatsapp.sendToOwner({
                document: buf,
                fileName: path.basename(target),
                mimetype: files.mimeFor(target),
                text: String(body.caption || ''),
              });
            }
            return json(res, 200, { ok: true, via: whatsapp.status(), file: target });
          }
          await whatsapp.sendToOwner(String(body.text || ''));
          return json(res, 200, { ok: true, via: whatsapp.status() });
        }

        case 'GET /api/solve/status':
          return json(res, 200, await solver.solverStatus(config, log));

        case 'POST /api/solve': {
          const body = await readJsonBody(req);
          const instructions = String(body.instructions ?? body.caption ?? '').slice(0, 2000).trim();
          if (body.screen) {
            const shot = await scr.capture({ portalTimeoutMs: Math.min(Number(config.portalTimeoutMs) || 30_000, 20_000) });
            const solved = await solver.solveQuestionImage(config, shot, {
              caption: instructions || 'Solve every question visible on this screen accurately.',
              autoDetect: false,
              harness,
              log,
            });
            if (!solved.ok) return json(res, 502, { ok: false, detail: solved.error || 'Solver failed.' });
            return json(res, 200, { ok: true, text: solved.text, stages: solved.stages, images: [dataUrl(shot)] });
          }
          if (body.imageBase64) {
            const rawBuf = Buffer.from(stripDataPrefix(body.imageBase64), 'base64');
            const mimeType = String(body.mimeType || 'image/png');
            const isDoc = mimeType === 'application/pdf' || /\.(pdf|docx|txt)$/i.test(String(body.fileName || ''));
            fs.mkdirSync(config.downloadsDir, { recursive: true });
            const cleanName = String(body.fileName || `question-${Date.now()}.${isDoc ? 'pdf' : 'png'}`).replace(/[^\w.\- ]/g, '_');
            const savedPath = path.join(config.downloadsDir, cleanName);
            fs.writeFileSync(savedPath, rawBuf);
            store.addDownload({ file: cleanName, kind: isDoc ? 'document' : 'image', ts: Date.now(), caption: instructions });
            const solved = isDoc
              ? await solver.solveQuestionDocument(config, rawBuf, { fileName: cleanName, mimeType, caption: instructions, harness, log })
              : await solver.solveQuestionImage(config, rawBuf, { caption: instructions, autoDetect: false, savedPath, harness, log });
            if (!solved.ok) return json(res, 502, { ok: false, detail: solved.error || 'Solver failed.' });
            return json(res, 200, { ok: true, text: solved.text, stages: solved.stages });
          }
          if (body.text) {
            const solved = await solver.solveQuestionText(config, String(body.text), { caption: instructions, harness, log });
            if (!solved.ok) return json(res, 502, { ok: false, detail: solved.error || 'Solver failed.' });
            return json(res, 200, { ok: true, text: solved.text, stages: solved.stages });
          }
          return json(res, 400, { detail: 'Provide imageBase64, screen:true, or text.' });
        }

        case 'GET /api/harness':
          return json(res, 200, harness ? harness.status() : { installed: false });

        case 'GET /api/harness/web-url': {
          if (!harness) return json(res, 503, { detail: 'Harness not initialised.' });
          const ws = harness.webStatus().running ? harness.webStatus() : await harness.startWeb();
          res.writeHead(200, { 'content-type': 'text/plain; charset=utf-8', 'cache-control': 'no-store' });
          return res.end(ws.localUrl || '');
        }

        case 'POST /api/harness/web': {
          if (!harness) return json(res, 503, { detail: 'Harness not initialised.' });
          const body = await readJsonBody(req);
          const action = String(body.action || 'start');
          const out = action === 'stop' ? await harness.stopWeb() : await harness.startWeb();
          return json(res, 200, { ok: true, web: out });
        }

        case 'POST /api/harness/install': {
          if (!harness) return json(res, 503, { detail: 'Harness not initialised.' });
          const out = await harness.install();
          return json(res, 200, out);
        }

        default:
          return json(res, 404, { detail: `No such route: ${route}` });
      }
    } catch (err) {
      log.error?.(`[bridge] ${route} failed: ${err.message}`);
      return json(res, err.status ?? 500, { detail: err.message });
    }
  });

  return {
    start() {
      return new Promise((resolve, reject) => {
        server.once('error', (err) => {
          if (err.code === 'EADDRINUSE') {
            reject(new Error(`Port ${config.port} is already in use. Another copy of the agent is probably running — check \`./start.sh --status\` / \`systemctl --user status observer-whatsapp-agent\`, or set PORT=<other> in .env.`));
          } else if (err.code === 'EACCES') {
            reject(new Error(`Not allowed to bind ${config.host}:${config.port}. Use a port above 1024 (PORT=8787).`));
          } else {
            reject(new Error(`Could not start the local bridge: ${err.message}`));
          }
        });
        server.listen(config.port, config.host, () => {
          const shownHost = config.host === '0.0.0.0' ? 'PC-IP' : config.host;
          log.info?.(`[bridge] listening on http://${config.host}:${config.port}`);
          log.info?.(`[bridge] phone app: http://${shownHost}:${config.port}/  (PIN: ${config.dashboardPin})`);
          log.info?.(`[bridge] direct link (keep private): http://${shownHost}:${config.port}/?t=${config.bridgeToken}`);
          log.info?.(`[bridge] token: ${config.bridgeToken}`);
          resolve(server);
        });
        server.on('error', (err) => log.error?.(`[bridge] server error: ${err.message}`));
      });
    },
    stop() { server.close(); },
  };
}
